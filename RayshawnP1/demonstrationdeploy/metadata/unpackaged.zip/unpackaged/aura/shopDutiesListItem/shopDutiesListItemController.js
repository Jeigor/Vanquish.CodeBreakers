({
	handleActiveChange : function(component, event, helper) {
		helper.updateItemHelper(component);
	}
})